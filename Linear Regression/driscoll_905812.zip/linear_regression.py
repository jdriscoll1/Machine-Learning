# Jordan Driscoll 905812

# This is the class for Linear Regression
class LinearRegression:
    def __init__(self):
        self.w = None   # The (d+1) x 1 numpy array weight matrix
        self.degree = 1
        
        
    def fit(self, X, y, CF = True, lam = 0, eta = 0.01, epochs = 1000, degree = 1):
        ''' Find the fitting weight vector and save it in self.w. 
            
            parameters: 
                X: n x d matrix of samples, n samples, each has d features, excluding the bias feature
                y: n x 1 matrix of lables
                CF: True - use the closed-form method. False - use the gradient descent based method
                lam: the ridge regression parameter for regularization
                eta: the learning rate used in gradient descent
                epochs: the maximum epochs used in gradient descent
                degree: the degree of the Z-space
        '''
        self.degree = degree
        X = MyUtils.z_transform(X, degree = self.degree)
        if CF:
            # Set degree = 3 
            # Set lam = 0.02211
            self._fit_cf(X, y, lam)
        else: 
            self._fit_gd(X, y, lam, eta, epochs)
 


            
    def _fit_cf(self, X, y, lam = 0):
        ''' Compute the weight vector using the closed-form method.
            Save the result in self.w
        
            X: n x d matrix, n samples, each has d features, excluding the bias feature
            y: n x 1 matrix of labels. Each element is the label of each sample. 
        '''
        
        # add bias column 
        X = np.insert(X, 0, 1, axis=1)
        # attain the X transpose
        X_T = np.transpose(X)
        
        n, d = np.shape(X)
        
        # Create the Identity Matrx: 
        I = np.identity(d)
       
        # Create (X^T * X)^-1
        a = (np.linalg.pinv(X_T @ X + lam * I))
        # Create X_T * y 
        b = X_T @ y 

        # Set w_star to create w_star: [X_T * y] * [X_T * y]
      
        self.w = a @ b
        

        ## delete the `pass` statement below.
        ## enter your code here that implements the closed-form method for
        ## linear regression 
        
                


    
    # X --> The set used for training
    # y --> The correct values in the training set 
    # lamda --> The reguralizaiton to make it so it is neither bias nor too variant
    # epochs --> The number of times it jumps
    def _fit_gd(self, X, y, lam = 0, eta = 0.01, epochs = 1000):
        ''' Compute the weight vector using the gradient desecent based method.
            Save the result in self.w

            X: n x d matrix, n samples, each has d features, excluding the bias feature
            y: n x 1 matrix of labels. Each element is the label of each sample. 
        '''

        ## enter your code here that implements the gradient descent based method
        ## for linear regression 
        
        ### Fix Up X ###
        
        
        
        # Add Bias Column 
        X = np.insert(X, 0, 1, axis=1)
        
        # Create the Transposed X: X_T
        X_T = np.transpose(X)
        
        n, d = np.shape(X)
        
        
        ### Initialize Variables ### 
        
        # Initialize w to a (dx1)x1 vector
        w_star = np.zeros((d,1))
        
        # Initialize a: I - (2nu / N) * (X_T @ X)
        
        # Initialize the identity matrix 
        I = np.identity(d)
        #a = I - (((2 * eta) / n) * (X_T @ X ))
        a = I - (((2 * eta) / n) * (X_T @ X + (lam * I)))
        
        # Initialize b: (2nu/N)*X_T @ y
        b = (2 * eta / n) * (X_T @ y)
        
        ### Run For Loop ###
        for i in range(epochs):
            # Update w
            w_star = a @ w_star + b
            
        self.w = w_star
  

    
    def predict(self, X):
        ''' parameter:
                X: n x d matrix, the n samples, each has d features, excluding the bias feature
            return:
                n x 1 matrix, each matrix element is the regression value of each sample
        '''
        X = MyUtils.z_transform(X, degree = self.degree)
        
        # This takes X and inserts a 0 columnn (the bias) in the front
        X = np.insert(X, 0, 1, axis=1)

        return X @ self.w
        #for x in X:
            #out[i] = x @ self.w
           # i+= 1
 
        #return out

  
        
        ## enter your code here that produces the label vector for the given samples saved
        ## in the matrix X. Make sure your predication is calculated at the same Z
        ## space where you trained your model. 


        

    
    # The error method
    def error(self, X, y):
        ''' parameters:
                X: n x d matrix of future samples
                y: n x 1 matrix of labels
            return: 
                the MSE for this test set (X,y) using the trained model
        '''
        # Transform to the proper z space
        X = MyUtils.z_transform(X, degree = self.degree)
        
        # Add on a 0 column at the front
        X = np.insert(X, [0], 1, axis=1)
        
        # Get the shape of X
        n,d = np.shape(X)
        
        # Tranpose X
        X_T = np.transpose(X)
        
        # dot together x and w 
        xw = X @ self.w 
        
        
        # Apply and later return the error function
        error = np.sum((xw - y)** 2) / n
        
        return error
        ## enter your code here that calculates the MSE between your predicted
        ## label vector and the given label vector y, for the sample set saved in matraix x
        ## Make sure your predication is calculated at the same Z space where you trained your model. 

        


